var data = [
  {
    "gotTime": "our expert translator can take a reasonable amount of time perfecting your translation.",
    "average": "you will get the best translation.",
    "yesterday": "we will do our best to make translation as soon as possible."
  }
]
